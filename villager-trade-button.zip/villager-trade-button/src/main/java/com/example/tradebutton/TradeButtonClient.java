package com.example.tradebutton;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.village.VillagerProfession;
import org.lwjgl.glfw.GLFW;

public class TradeButtonClient implements ClientModInitializer {

    private static KeyBinding tradeKey;

    @Override
    public void onInitializeClient() {
        tradeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.tradebutton.trade",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.tradebutton"
        ));

        // Nhấn phím => mở giao dịch với dân làng đang nhìn vào
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (tradeKey.wasPressed()) {
                MerchantEntity target = getTradeTarget(client);
                if (target != null && client.interactionManager != null) {
                    client.interactionManager.interactEntity(client.player, target, Hand.MAIN_HAND);
                }
            }
        });

        // Vẽ nút dưới tâm ngắm
        HudRenderCallback.EVENT.register((DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (getTradeTarget(client) == null) return;

            TextRenderer font = client.textRenderer;
            MutableText label = Text.translatable("tradebutton.trade")
                    .append(" [")
                    .append(tradeKey.getBoundKeyLocalizedText())
                    .append("]");

            int textW = font.getWidth(label);
            int w = textW + 16;
            int h = 18;
            int x = ctx.getScaledWindowWidth() / 2 - w / 2;
            int y = ctx.getScaledWindowHeight() / 2 + 16;

            ctx.fill(x, y, x + w, y + h, 0xB0000000);      // nền
            ctx.drawBorder(x, y, w, h, 0xFFFFFFFF);         // viền
            ctx.drawTextWithShadow(font, label, x + 8, y + 5, 0xFFFFFF);
        });
    }

    /** Trả về dân làng / thương nhân đang được ngắm tới và có thể giao dịch, nếu không thì null. */
    private static MerchantEntity getTradeTarget(MinecraftClient client) {
        if (client.player == null || client.world == null) return null;
        if (client.currentScreen != null || client.options.hudHidden) return null;
        if (client.crosshairTarget == null || client.crosshairTarget.getType() != HitResult.Type.ENTITY) return null;

        Entity e = ((EntityHitResult) client.crosshairTarget).getEntity();

        if (e instanceof VillagerEntity v) {
            if (v.isBaby() || v.isSleeping()) return null;
            var prof = v.getVillagerData().getProfession();
            if (prof.matchesKey(VillagerProfession.NONE) || prof.matchesKey(VillagerProfession.NITWIT)) return null;
            return v;
        }
        if (e instanceof WanderingTraderEntity t) return t;
        return null;
    }
}
