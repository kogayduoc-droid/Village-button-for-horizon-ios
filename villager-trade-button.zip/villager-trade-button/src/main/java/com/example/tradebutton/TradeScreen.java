package com.example.tradebutton;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;

/** Màn hình trong suốt: hiện con trỏ chuột và nút "Giao dịch" để click. Nhấn Esc để thoát. */
public class TradeScreen extends Screen {

    private final EntityHitResult hit;
    private final Entity target;

    public TradeScreen(EntityHitResult hit) {
        super(Component.translatable("tradebutton.trade"));
        this.hit = hit;
        this.target = hit.getEntity();
    }

    @Override
    protected void init() {
        int w = 100, h = 20;
        this.addRenderableWidget(
                Button.builder(Component.translatable("tradebutton.trade"), btn -> trade())
                        .bounds(this.width / 2 - w / 2, this.height / 2 + 16, w, h)
                        .build());
    }

    private void trade() {
        var mc = this.minecraft;
        mc.gui.setScreen(null);
        if (mc.gameMode != null && mc.player != null) {
            mc.gameMode.interact(mc.player, target, hit, InteractionHand.MAIN_HAND);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    // Không làm mờ/tối nền để vẫn nhìn thấy dân làng.
    // (cố ý không dùng @Override để build không lỗi nếu tên hàm khác đi)
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
    }

    // Không tạm dừng game khi mở màn hình này.
    public boolean isPauseScreen() {
        return false;
    }

    // Tự đóng nếu dân làng biến mất hoặc ở quá xa.
    public void tick() {
        if (this.minecraft == null || this.minecraft.player == null
                || !target.isAlive()
                || this.minecraft.player.distanceToSqr(target) > 25.0) {
            this.minecraft.gui.setScreen(null);
        }
    }
}
