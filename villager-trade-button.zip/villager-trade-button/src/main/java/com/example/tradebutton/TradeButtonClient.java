package com.example.tradebutton;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

public class TradeButtonClient implements ClientModInitializer {

    public static KeyMapping cursorKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("tradebutton", "main"));

        cursorKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.tradebutton.cursor", InputConstants.KEY_LALT, category));

        // Nhấn phím khi đang nhìn dân làng => mở màn hình có chuột + nút bấm được
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (cursorKey.consumeClick()) {
                EntityHitResult hit = findTarget(mc);
                if (hit != null) {
                    mc.gui.setScreen(new TradeScreen(hit));
                }
            }
        });

        // Gợi ý nút trên HUD khi đang ngắm dân làng
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("tradebutton", "trade_button"),
                TradeButtonClient::extractHud);
    }

    private static void extractHud(GuiGraphicsExtractor g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (findTarget(mc) == null) return;

        Component label = Component.translatable("tradebutton.trade")
                .append(" [")
                .append(cursorKey.getTranslatedKeyMessage())
                .append("]");

        int w = mc.font.width(label) + 16;
        int h = 18;
        int x = mc.getWindow().getGuiScaledWidth() / 2 - w / 2;
        int y = mc.getWindow().getGuiScaledHeight() / 2 + 16;

        g.fill(x, y, x + w, y + h, 0xB0000000);
        g.outline(x, y, w, h, 0xFFFFFFFF);
        g.text(mc.font, label, x + 8, y + 5, 0xFFFFFFFF, true);
    }

    /** Trả về kết quả ngắm trúng dân làng / thương nhân lang thang, hoặc null. */
    public static EntityHitResult findTarget(Minecraft mc) {
        if (mc.player == null || mc.level == null) return null;
        if (mc.gui.screen() != null) return null;
        if (!(mc.hitResult instanceof EntityHitResult hit)) return null;

        Entity e = hit.getEntity();
        String id = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
        if (!id.equals("villager") && !id.equals("wandering_trader")) return null;

        if (e instanceof LivingEntity le && (le.isBaby() || le.isSleeping())) return null;
        return hit;
    }
}
